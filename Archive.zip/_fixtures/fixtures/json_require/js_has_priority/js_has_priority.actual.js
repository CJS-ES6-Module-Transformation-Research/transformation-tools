var p = require('./package');
