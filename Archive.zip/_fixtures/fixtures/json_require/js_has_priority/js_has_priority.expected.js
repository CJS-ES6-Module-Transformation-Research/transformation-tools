var p = require('./package.js');

