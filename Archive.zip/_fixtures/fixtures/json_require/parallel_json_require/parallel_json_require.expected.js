var x = require('./package.json.cjs');

