function x(a, b){
	return a + b;
}