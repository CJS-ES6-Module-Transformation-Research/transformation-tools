module.exports = {
	a:"b"
}

module.exports.hello;