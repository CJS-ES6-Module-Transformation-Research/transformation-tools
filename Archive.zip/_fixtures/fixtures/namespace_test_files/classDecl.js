class HelloWorld{
	constructor(){}
}