//index.js

console.log('index.js')
var x = require(''); 
module.exports = {filename:"index.js",isTrue:x};
