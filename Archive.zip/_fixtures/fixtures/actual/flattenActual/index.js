#!/Users/sam/.nvm/versions/node/v12.16.0/bin/node

var src = require('./src/index.js')
let  {expect} = require('chai');
var lib = require('./lib.js')
console.log('#!/bin/bash')

var x = 3, y = 2;

var r1 = require('chai'), r2 = require('./lib.js')

var r3 = require('./lib.js'), beta = 2;

var alpha = 1 , r4 = require('chai');

var  {it, assert} = require('chai'), xx = 32;

var   yy = 64 , {expect2} = require('chai');