#!/Users/sam/.nvm/versions/node/v12.16.0/bin/node

var src = require('./src/index.js')
let {expect} = require('chai')
var lib = require('./lib.js')
console.log('#!/bin/bash')

var x = 3
var y = 2;

var r1 = require('chai')
var r2 = require('./lib.js')

var r3 = require('./lib.js')
var beta = 2;

var alpha = 1;
var r4 = require('chai');

var {it, assert} = require('chai')
var xx = 32;

var yy = 64
var {expect2} = require('chai')
