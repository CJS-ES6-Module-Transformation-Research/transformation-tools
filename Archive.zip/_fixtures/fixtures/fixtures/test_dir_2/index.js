#!/Users/sam/.nvm/versions/node/v12.16.0/bin/node

var src = require('./src/index')
let  {expect} = require('chai')
var lib = require('./lib')
console.log('#!/bin/bash')
const app = require('express')

app.post