module.exports = require("./package")
console.log('#!/bin/bash')