module.exports = require("./package")
console.log('#!/bin/bash')
let a, b, c;
let g = [1,2,3]


for (let j = a, k = require('lodash').includes; c > a > 0; c--){
	console.log("hello world ");
}


for (let i = 0; i < g.length; i++){
	for (let j = require('mocha'), k = i * 2; 32 - k > 0; ){
		console.log(i+ k);
	}
}