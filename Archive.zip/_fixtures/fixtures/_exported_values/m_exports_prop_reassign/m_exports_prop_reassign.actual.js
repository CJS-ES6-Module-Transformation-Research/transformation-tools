module.exports.x = 'x'
module.exports.x = 'y'