var x = 'x'
x = 'y'
export {x};