var defaultExport = {};
class c {
    method() {
    }
}
defaultExport = c;
export default defaultExport;