var z = 'z'
var a = 'a'
export {z, a};  