var x = 'y'; 
export {x};