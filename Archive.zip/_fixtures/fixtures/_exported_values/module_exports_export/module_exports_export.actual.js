module.exports.x = 'y'
