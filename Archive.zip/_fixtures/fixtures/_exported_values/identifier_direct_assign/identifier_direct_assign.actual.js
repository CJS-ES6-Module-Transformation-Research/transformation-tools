var z = 'z'
module.exports = z;  