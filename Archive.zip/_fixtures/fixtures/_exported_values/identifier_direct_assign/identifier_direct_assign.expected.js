var defaultExport = {};
var z = 'z'
defaultExport = z
export default defaultExport;