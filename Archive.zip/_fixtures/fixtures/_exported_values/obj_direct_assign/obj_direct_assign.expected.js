
var defaultExport = {}
const a = 'a';
const b = 'b';
defaultExport = {
	a:a,
	b:b
};
export {a,b}