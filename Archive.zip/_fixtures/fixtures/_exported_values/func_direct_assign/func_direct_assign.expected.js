var defaultExport = {};
defaultExport = function (a,b){return a + b}
export default defaultExport;