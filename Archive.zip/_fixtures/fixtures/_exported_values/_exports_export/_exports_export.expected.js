var x = 'x'
export {x}