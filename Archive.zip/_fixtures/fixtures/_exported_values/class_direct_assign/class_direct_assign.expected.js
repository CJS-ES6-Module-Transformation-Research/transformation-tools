var defaultExport = {};
defaultExport = class {
	method(){
		 
	}
}
export default defaultExport;