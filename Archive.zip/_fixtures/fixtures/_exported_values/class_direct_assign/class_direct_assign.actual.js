module.exports = class {
	method(){
		 
	}
}