
var defaultExport = {}
const a = 'a';
defaultExport = {
	a:a
};
var b = 'b';
export {a,b}