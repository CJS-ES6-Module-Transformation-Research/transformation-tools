import _moduleAccess_mocha from 'mocha'
import _moduleAccess_lodash from 'lodash'
import _moduleAccess___package from './package.json';

module.exports = _moduleAccess___package;
console.log('#!/bin/bash')
let a;
let b;
let c;
let g = [1, 2, 3];

for (let j = a, k = _moduleAccess_lodash.includes; c > a > 0; c--) {
    console.log("hello world ");
}


for (let i = 0; i < g.length; i++) {
    for (let j = _moduleAccess_mocha, k = i * 2; 32 - k > 0;) {
        console.log(i + k);
    }
}