#!/Users/sam/.nvm/versions/node/v12.16.0/bin/node

import lib from './lib.js';
import r2 from './lib.js';
import r3 from './lib.js';
import src from './src/index.js';
import _moduleAccess_chai from 'chai';
import r1 from 'chai';
import r4 from 'chai';
let {expect} = _moduleAccess_chai;
console.log('#!/bin/bash');
var x = 3;
var y = 2;
var beta = 2;
var alpha = 1;
var {it, assert} = _moduleAccess_chai;
var xx = 32;
var yy = 64;
var {expect2} = _moduleAccess_chai;
