var x = require('x')
x.y = 3 