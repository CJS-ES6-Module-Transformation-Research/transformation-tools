var x= require('x')

let xx = new x.y()
let A = x.z(x.a)