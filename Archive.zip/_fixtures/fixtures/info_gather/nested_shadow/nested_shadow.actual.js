var x = require('x')
var z = x.z 
function a(a){
	x.y()
}