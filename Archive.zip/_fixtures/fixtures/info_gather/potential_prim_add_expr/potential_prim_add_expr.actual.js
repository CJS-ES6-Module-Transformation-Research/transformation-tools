var x = require('x')
let c = x.y + x.z ;