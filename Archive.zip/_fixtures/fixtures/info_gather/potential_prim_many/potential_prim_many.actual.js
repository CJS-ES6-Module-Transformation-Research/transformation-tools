var x = require('x')
let c = x.y || 3 ;
console.log(x.z)