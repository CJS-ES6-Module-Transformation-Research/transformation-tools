import { sep as sep0 } from 'path';
var sep = sep0;
let root = sep;