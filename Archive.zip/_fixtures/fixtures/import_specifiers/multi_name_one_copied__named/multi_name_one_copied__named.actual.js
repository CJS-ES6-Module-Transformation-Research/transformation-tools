var path = require('path');
 
let root = path.sep;
let sbin = path.join(root, 'sbin');