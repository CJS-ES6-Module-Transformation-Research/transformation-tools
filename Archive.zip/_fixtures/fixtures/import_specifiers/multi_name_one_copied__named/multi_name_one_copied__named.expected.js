import {
    sep as sep0,
    join
} from 'path';
var sep = sep0;
let root = sep;
let sbin = join(root, 'sbin');