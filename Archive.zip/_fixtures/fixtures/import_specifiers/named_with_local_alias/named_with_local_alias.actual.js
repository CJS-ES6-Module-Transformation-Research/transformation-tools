var path = require('path');
let join = '/join';
path.join(join, 'with');