import { join as join0 } from 'path';
let join = '/join';
join0(join, 'with');