import fs from 'fs';
fs.prop = 'value';