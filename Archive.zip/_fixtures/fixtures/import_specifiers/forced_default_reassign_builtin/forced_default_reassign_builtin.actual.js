var fs = require('fs');
fs.prop = 'value';