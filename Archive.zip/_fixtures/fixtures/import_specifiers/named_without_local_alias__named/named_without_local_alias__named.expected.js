import { readFileSync } from 'fs';
let pkg = readFileSync('./package.json');