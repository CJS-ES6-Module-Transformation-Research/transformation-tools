var fs = require('fs');
let pkg = fs.readFileSync('./package.json');