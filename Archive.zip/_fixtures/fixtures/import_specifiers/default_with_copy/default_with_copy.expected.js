import x from 'x'
var y = x.y ;
let z = y + 3