var x = require('x')
let z = x.y + 3