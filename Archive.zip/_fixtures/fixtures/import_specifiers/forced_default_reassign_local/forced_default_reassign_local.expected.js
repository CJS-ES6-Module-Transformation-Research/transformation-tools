import x from './mod.js';
 x.prop = 'value';