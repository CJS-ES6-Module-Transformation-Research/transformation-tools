var x =require ( './mod.js');
x.prop = 'value';