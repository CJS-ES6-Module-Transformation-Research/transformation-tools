import * as path from 'path';
import pretty from 'installed';
var pritify = pretty(console.log);
pritify(path.join('a', 'b'));