var path = require('path');
let usrLocalBin = path.sep + 'usr' + path.sep + 'local' + path.sep + 'bin';