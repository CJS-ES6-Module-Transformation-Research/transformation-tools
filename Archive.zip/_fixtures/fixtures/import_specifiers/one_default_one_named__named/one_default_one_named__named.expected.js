import { join } from 'path';
import pretty from 'installed';
var pritify = pretty(console.log);
pritify(join('a', 'b'));