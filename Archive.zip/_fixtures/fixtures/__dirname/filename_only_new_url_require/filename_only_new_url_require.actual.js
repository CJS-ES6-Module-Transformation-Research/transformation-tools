
console.log(__filename)