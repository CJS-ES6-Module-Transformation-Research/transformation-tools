var __filename = require('url').fileURLToPath(IMPORT_META_URL);
var __dirname = require('path').dirname(__filename);
var path = require('path');
 

console.log(path.join(__dirname, "hello.js")) 