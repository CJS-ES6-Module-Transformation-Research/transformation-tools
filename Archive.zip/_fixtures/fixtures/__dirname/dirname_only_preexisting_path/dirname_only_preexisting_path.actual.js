var path = require('path');
console.log(path.join(__dirname, "hello.js"))