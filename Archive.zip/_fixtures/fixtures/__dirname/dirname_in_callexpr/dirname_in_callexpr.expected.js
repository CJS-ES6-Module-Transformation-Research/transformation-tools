var __filename = require('url').fileURLToPath(IMPORT_META_URL);
var __dirname = require('path').dirname(__filename);

let z = require(__dirname +'/'+'index.js');