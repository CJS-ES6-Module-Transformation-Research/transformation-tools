var __filename = require('url').fileURLToPath(IMPORT_META_URL);
var __dirname = require('path').dirname(__filename);
var c = new _class(__dirname)