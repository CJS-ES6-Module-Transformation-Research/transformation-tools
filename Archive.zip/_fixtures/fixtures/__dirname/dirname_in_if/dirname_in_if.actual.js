if (__dirname==="/usr/local/bin"){
console.log('bin'); 
}
