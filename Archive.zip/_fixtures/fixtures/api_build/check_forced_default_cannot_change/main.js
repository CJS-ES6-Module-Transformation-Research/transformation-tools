var v = require('./mod.js')
v.w = 'vw'