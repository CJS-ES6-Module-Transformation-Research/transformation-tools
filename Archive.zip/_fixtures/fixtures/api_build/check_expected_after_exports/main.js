var m1 = require('./mod.js')
var m2 = require('./mod2.js')