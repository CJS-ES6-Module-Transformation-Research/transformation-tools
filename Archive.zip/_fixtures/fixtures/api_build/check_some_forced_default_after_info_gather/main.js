var m = require('./mod.js')
m.x = 3; 