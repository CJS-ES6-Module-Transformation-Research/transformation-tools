import * as path from 'path';
var sep = path.sep;
let usrLocalBin = sep + 'usr' + sep + 'local' + sep + 'bin';