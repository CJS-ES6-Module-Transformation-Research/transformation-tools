module.exports = {a:'a'}
module.exports.b ='b'
