
module.exports = require('./package.json');