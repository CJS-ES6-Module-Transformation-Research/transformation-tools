
module.exports = {
    'filename': 'package.json',
    'isTrue': 'x'
};
