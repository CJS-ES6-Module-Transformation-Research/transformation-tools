var x= require('x')

let xx = x.y
x.z() 