var x= require('x')
x.call() 
let xx = x.y