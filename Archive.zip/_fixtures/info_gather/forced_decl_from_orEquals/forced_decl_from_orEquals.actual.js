var x = require ('x')
var z = x.y|| x 			