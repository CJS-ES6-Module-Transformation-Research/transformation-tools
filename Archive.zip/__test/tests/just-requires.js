var x = require('x')
var mod = require('./mod.ds')
require('./mod.ds')
console.log()