var _x,_y,_z
var x = 3
_x = _x
module.exports.x = _x
_y = 'hello
module.exports = _y
_z = ['hi', 'hello']
module.exports.z = z