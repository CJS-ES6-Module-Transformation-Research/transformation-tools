var 
//declare variable
var z = 'hello'
var mod = require('mod')

HI MOM!
module.exports
module.exports.something
module.exports = 'hello'
x.y
require('./index.js')

//a block statement has a curly after the () 
// hit enter BETWEEN the braces
if (x){
	
}
if (x){
	somethingHere()
}
// between two quotes. either ok, just match them 
''
""  

for (var i = 0; i < 9; i++){

}

var myObject = {
	name:"martha"   , // commas between key/value pairs
				 likes:['pools']
				}
