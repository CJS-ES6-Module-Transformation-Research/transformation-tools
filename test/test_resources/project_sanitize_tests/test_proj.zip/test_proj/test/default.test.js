var all = require('..')
var all2 = require('../')
var {destr, truc, ture} = consCarCdr

