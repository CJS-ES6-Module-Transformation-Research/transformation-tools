let fs = require('fs')
let libJS = require('../lib')
let libDir = require('../lib/').asdf

module.exports = {libJS, libDir}