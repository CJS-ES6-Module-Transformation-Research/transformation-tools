function f(){
	console.log(__dirname)
}
module.exports = "source index"
 