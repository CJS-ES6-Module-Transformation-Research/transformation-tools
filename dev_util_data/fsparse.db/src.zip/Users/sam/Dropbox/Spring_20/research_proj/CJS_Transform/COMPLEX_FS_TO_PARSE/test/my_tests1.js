module.exports =  (function(i) {console.log('hello, this is the test: '+ i)})(1)
	