//test/index.js

console.log('test/index.js')
var x = require('mocha');
module.exports = {filename:"test/index.js",isTrue:x};
