//test/edge/edge_case_tests.js

console.log('test/edge/edge_case_tests.js')
var x = require('mocha');
module.exports = {filename:"test/edge/edge_case_tests.js",isTrue:x};
