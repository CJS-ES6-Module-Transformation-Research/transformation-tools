//index.js

console.log('index.js')
var x = require('./package.json'); 
module.exports = {filename:"index.js",isTrue:x};
