//src/util/stringProcess.js

console.log('src/util/stringProcess.js')
var x = require('mocha');
module.exports = {filename:"src/util/stringProcess.js",isTrue:x};
