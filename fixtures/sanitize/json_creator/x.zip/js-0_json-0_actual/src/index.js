//src/index.js

console.log('src/index.js')
var x = require('mocha');
module.exports = {filename:"src/index.js",isTrue:x};
